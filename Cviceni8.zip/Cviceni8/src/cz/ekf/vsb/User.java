
package cz.ekf.vsb;

import java.math.BigDecimal;

public class User {
    private String name;
    private String username;
    private String password;
    private Boolean isMale;
    private Integer age;
    private BigDecimal priceToPay;

    public User(String name, String username, String password, Boolean isMale, Integer age, BigDecimal priceToPay) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.isMale = isMale;
        this.age = age;
        this.priceToPay = priceToPay;
    }
    
    public User(String name, String username, String password) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.priceToPay = new BigDecimal(Math.random());
    }
   
   
    public BigDecimal getPriceToPay() {
        return priceToPay;
    }

    public void setPriceToPay(BigDecimal priceToPay) {
        this.priceToPay = priceToPay;
    }
    
    
    
    public String getPassword() {
        return password;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String validate(String jmeno, String heslo){
      if(jmeno != null && jmeno.equals(this.name)){
          if(heslo != null && heslo.equals(this.password)){
              return "Vitej";
          } else {
              return "spatne heslo";
          }
      } else {
          return "neznam";
      }
    }
}
