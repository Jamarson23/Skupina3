
package cz.ekf.vsb;

import java.math.BigDecimal;
import java.util.Scanner;

public class Cviceni8 {

 
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      // plny konstruktor
      User david = new User("David","David", "1234", true, 45, new BigDecimal("150"));
      // nueplny konsturktor
      User jirka = new User("Jirka","David", "4321");
      
      // vlozim do pole
      User[] users = new User[] {david, jirka};
       
      
      // vstup z konzole
      System.out.println("Zadej heslo: ");
      String heslo = sc.nextLine();
      
      System.out.println("zadej jmeno: ");
      String jmeno = sc.nextLine();
      
      // projdi uzivatele
      for(User us : users){
          if(us.getName().equals(jmeno)){
              System.out.println(us.validate(jmeno, heslo));
              System.out.println(jmeno.substring(1));
          }
      }
    }
    
    
    
}
